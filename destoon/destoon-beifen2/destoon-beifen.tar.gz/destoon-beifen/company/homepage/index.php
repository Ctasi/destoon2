<?php
define('DT_REWRITE', true);
require '../config.inc.php';
require '../../common.inc.php';
$file = 'homepage';
require DT_ROOT.'/module/'.$module.'/index.inc.php';
?>
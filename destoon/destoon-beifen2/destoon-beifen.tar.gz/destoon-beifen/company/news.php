<?php
define('DT_REWRITE', true);
$moduleid = 4;
require '../common.inc.php';
$action = 'company';
require DT_ROOT.'/module/'.$module.'/news.inc.php';
?>
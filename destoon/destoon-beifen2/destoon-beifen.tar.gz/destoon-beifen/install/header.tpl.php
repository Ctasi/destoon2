<?php
defined('IN_DESTOON') or exit('Access Denied');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html;charset=<?php echo $CFG['charset'];?>" />
<title>DESTOON B2B网站管理系统V<?php echo DT_VERSION;?> R<?php echo DT_RELEASE;?> <?php echo strtoupper($CFG['charset']);?> 安装向导</title>
<meta name="generator" content="DESTOON B2B - www.destoon.com"/>
<link rel="stylesheet" type="text/css" href="style.css" />
<script type="text/javascript">
function $(ID) {return document.getElementById(ID);}
</script>
</head>
<body>
<table width="100%" height="100%" cellpadding="0" cellspacing="0">
<tr>
<td>
<table cellpadding="0" cellspacing="0" align="center" class="out">
<tr>
<td class="in">
<?php
defined('DT_ADMIN') or exit('Access Denied');
$menu = array(
	array('排名推广', '?moduleid=3&file=spread'),
	array('广告管理', '?moduleid=3&file=ad'),
	array('公告管理', '?moduleid=3&file=announce'),
	array('单页管理', '?moduleid=3&file=webpage'),
	array('友情链接', '?moduleid=3&file=link'),
	array('评论管理', '?moduleid=3&file=comment'),
	array('留言管理', '?moduleid=3&file=guestbook'),
	array('积分换礼', '?moduleid=3&file=gift'),
	array('投票管理', '?moduleid=3&file=vote'),
	array('票选管理', '?moduleid=3&file=poll'),
	array('表单管理', '?moduleid=3&file=form'),
	array('模块设置', '?moduleid=3&file=setting'),
);
?>